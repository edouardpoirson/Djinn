<!DOCTYPE html>
<html lang="fr">
    <head>
        <title>Djinn</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link rel="stylesheet/less" href="less/bootstrap.less">
        <script src="less/less.js"></script>
    </head>
<body>
<div class="navbar navbar-fixed-top">
  <div class="navbar-inner">
    <div class="container-fluid">
      <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </a>
      <a class="brand" href="#"><img src="img/logo.png"></a>
      <div class="nav-collapse">
        <ul class="nav">
          <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">Souhaits récents <b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="#">Souhaits les plus soutenus</a></li>
                <li><a href="#">Souhaits les plus comentés</a></li>
                <li><a href="#">Souhaits les plus populaires</a></li>
              </ul>
            </li>
          <li><a href="#contact">Souhaits réalisés</a></li>
          <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">A propos <b class="caret"></b></a>
            <ul class="dropdown-menu">
              <li><a href="#">A propos</a></li>
              <li><a href="#">L'équipe</a></li>
              <li class="divider"></li>
              <li><a href="#">Le blog</a></li>
              <li><a href="#">Le forum</a></li>
              <li class="divider"></li>
              <li><a href="#">Copyright</a></li>
              <li><a href="#">Condition</a></li>
              <li><a href="#">Confidentialité</a></li>
            </ul>
          </li>
        </ul>      
        <ul class="nav pull-right" id="login-connect">
          <li class="dropdown">
            <a class="dropdown-toggle" data-toggle="dropdown" href="#"><i class="nav-me"></i> <b class="caret"></b></a>
            <ul class="dropdown-menu">
              <li class="current-user"><a href="#"><img src="img/profile-picture/img-1.jpg" class="profile-avatar" width="32" height="32"><span>Edouard Poirson <small>Voir ma page profil</small></span></a></li>
              <li class="divider"></li>
              <li><a href="#"><i class="icon-star"></i> Mes souhaits</a></li>
              <li><a href="#"><i class="icon-envelope"></i> Messages privées</a></li>
              <li class="divider"></li>
              <li><a href="#"><i class="icon-cog"></i> Paramètres</a></li>
              <li><a href="#"><i class=" icon-question-sign"></i> Aide</a></li>
              <li class="divider"></li>
              <li><a href="#"><i class="icon-remove-sign"></i> Déconnexion</a></li>
            </ul>
          </li>
        </ul>
        <div class="input-prepend pull-right" id="research">
              <span class="add-on"><i class="icon-search"></i></span><input placeholder="Rechercher" class="span3" id="inputIcon" type="text">
        </div>
      </div><!--/.nav-collapse -->

    </div>
  </div>
</div>

<div class="container-fluid">
 <div class="row-fluid" id="content_wrapper">
     <div class="span3" id="kill-sidebar">
      <div class="well sidebar-nav-fixed">
        <div class="group-sidebar">
          <h2><strong>Quels sont vos souhaits ?</strong> Réalisez vos souhaits et ceux des autres.</h2>
          <h6 id="pics-total">
            <strong>6.163.413</strong>souhaits ont déjà<br>été éxaucés<p id="mascot"></p>
          </h6>
        </div>
        <div class="group-sidebar">
          <h3>Réseaux sociaux</h3>
          <a href="https://twitter.com/share" class="twitter-share-button" data-lang="fr">Tweeter</a>
          <script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
          
          <div class="fb-like" data-send="false" data-layout="button_count" data-width="450" data-show-faces="false"></div>

          <div class="g-plusone" data-size="tall" data-annotation="inline" data-width="300"></div>
        </div>
        <div class="group-sidebar">
          <h3>Souhait à la une</h3>
        </div>
      </div><!--/.well -->
    </div><!--/span-->

    <div class="span9 span-fixed-sidebar">
      <div id="containermasory" class="clearfix">
            <div class="box">
              <header>
                <h3>Je souhaite faire un featuring avec Booba</h3>
              </header>
              <div class="img-bloc">
                <div class="help-wish"><i class="icon-thumbs-up"></i> J'aide</div>
                <div class="like-wish"><i class="icon-heart"></i> Je soutiens</div>
                <div class="comment-wish"><i class="icon-comment"></i> Je commente</div>
                <img src="img/wish-picture/img-1.png">
              </div>
              <div class="popularity">
               <span>100000 <i class="icon-eye-open"></i></span>
               <span>10 <i class="icon-heart"></i></span>
               <span>100 <i class=" icon-comment"></i></span>
              </div>
              <div class="comments">
               <div class="comment"><img class="commentAvatar" src="http://placehold.it/20x20"><p>Par <a href="">Thomas Bertin</a></p></div>
                <div class="comment"><img class="commentAvatar" src="http://placehold.it/20x20"><p><a href="">Matieu Raverdy</a> Trop stylé ton souhait, je kiffe</p></div>
                <div class="comment"><img class="commentAvatar" src="http://placehold.it/20x20"><p><a href="">Samir Nasri</a> preums</p></div>
                <div class="comment"><img class="commentAvatar" src="http://placehold.it/20x20"><p><a href="">Tartempion</a> Yeahhhhhhhhhh blabblalalalalalallalalala alzlazla</p></div>
                <div class="comment see-more-comments"><a href="">Voir tous les commentaires...</a></div>
              </div>
            </div>

            <div class="box">
              <header>
                <h3>Je souhaite faire un tour du monde</h3>
              </header>
              <div class="img-bloc">
                <div class="help-wish"><i class="icon-thumbs-up"></i> J'aide</div>
                <div class="like-wish"><i class="icon-heart"></i> Je soutiens</div>
                <div class="comment-wish"><i class="icon-comment"></i> Je commente</div>
                <img src="img/wish-picture/img-2.png">
              </div>
              <div class="popularity">
               <span>100000 <i class="icon-eye-open"></i></span>
               <span>10 <i class="icon-heart"></i></span>
               <span>100 <i class=" icon-comment"></i></span>
              </div>
              <div class="comments">
               <div class="comment"><img class="commentAvatar" src="http://placehold.it/20x20"><p>Par <a href="">Thomas Bertin</a></p></div>
                <div class="comment"><img class="commentAvatar" src="http://placehold.it/20x20"><p><a href="">Matieu Raverdy</a> Trop stylé ton souhait, je kiffe</p></div>
                <div class="comment"><img class="commentAvatar" src="http://placehold.it/20x20"><p><a href="">Samir Nasri</a> preums</p></div>
                <div class="comment"><img class="commentAvatar" src="http://placehold.it/20x20"><p><a href="">Tartempion</a> Yeahhhhhhhhhh blabblalalalalalallalalala alzlazla</p></div>
                <div class="comment see-more-comments"><a href="">Voir tous les commentaires...</a></div>
              </div>            
            </div>

            <div class="box">
              <header>
                <h3>Je souhaite baiser Clara Morgan</h3>
              </header>
              <div class="img-bloc">
                <div class="help-wish"><i class="icon-thumbs-up"></i> J'aide</div>
                <div class="like-wish"><i class="icon-heart"></i> Je soutiens</div>
                <div class="comment-wish"><i class="icon-comment"></i> Je commente</div>
                <img src="img/wish-picture/img-3.png">
              </div>
              <div class="popularity">
               <span>100000 <i class="icon-eye-open"></i></span>
               <span>10 <i class="icon-heart"></i></span>
               <span>100 <i class=" icon-comment"></i></span>
              </div>
              <div class="comments">
               <div class="comment"><img class="commentAvatar" src="http://placehold.it/20x20"><p>Par <a href="">Thomas Bertin</a></p></div>
                <div class="comment"><img class="commentAvatar" src="http://placehold.it/20x20"><p><a href="">Matieu Raverdy</a> Trop stylé ton souhait, je kiffe</p></div>
                <div class="comment"><img class="commentAvatar" src="http://placehold.it/20x20"><p><a href="">Samir Nasri</a> preums</p></div>
                <div class="comment"><img class="commentAvatar" src="http://placehold.it/20x20"><p><a href="">Tartempion</a> Yeahhhhhhhhhh blabblalalalalalallalalala alzlazla</p></div>
                <div class="comment see-more-comments"><a href="">Voir tous les commentaires...</a></div>
              </div>            
            </div>

            <div class="box">
              <header>
                <h3>Je souhaite aller à un match de Tours</h3>
              </header>
              <div class="img-bloc">
                <div class="help-wish"><i class="icon-thumbs-up"></i> J'aide</div>
                <div class="like-wish"><i class="icon-heart"></i> Je soutiens</div>
                <div class="comment-wish"><i class="icon-comment"></i> Je commente</div>
                <img src="img/wish-picture/img-4.png">
              </div>
              <div class="popularity">
               <span>100000 <i class="icon-eye-open"></i></span>
               <span>10 <i class="icon-heart"></i></span>
               <span>100 <i class=" icon-comment"></i></span>
              </div>
              <div class="comments">
               <div class="comment"><img class="commentAvatar" src="http://placehold.it/20x20"><p>Par <a href="">Thomas Bertin</a></p></div>
                <div class="comment"><img class="commentAvatar" src="http://placehold.it/20x20"><p><a href="">Matieu Raverdy</a> Trop stylé ton souhait, je kiffe</p></div>
                <div class="comment"><img class="commentAvatar" src="http://placehold.it/20x20"><p><a href="">Samir Nasri</a> preums</p></div>
                <div class="comment"><img class="commentAvatar" src="http://placehold.it/20x20"><p><a href="">Tartempion</a> Yeahhhhhhhhhh blabblalalalalalallalalala alzlazla</p></div>
                <div class="comment see-more-comments"><a href="">Voir tous les commentaires...</a></div>
              </div>   
            </div>

            <div class="box">
              <header>
                <h3>Je souhaite apprendre à jouer de la guitare</h3>
              </header>
              <div class="img-bloc">
                <div class="help-wish"><i class="icon-thumbs-up"></i> J'aide</div>
                <div class="like-wish"><i class="icon-heart"></i> Je soutiens</div>
                <div class="comment-wish"><i class="icon-comment"></i> Je commente</div>
                <img src="img/wish-picture/img-5.png">
              </div>
              <div class="popularity">
               <span>100000 <i class="icon-eye-open"></i></span>
               <span>10 <i class="icon-heart"></i></span>
               <span>100 <i class=" icon-comment"></i></span>
              </div>
              <div class="comments">
               <div class="comment"><img class="commentAvatar" src="http://placehold.it/20x20"><p>Par <a href="">Thomas Bertin</a></p></div>
                <div class="comment"><img class="commentAvatar" src="http://placehold.it/20x20"><p><a href="">Matieu Raverdy</a> Trop stylé ton souhait, je kiffe</p></div>
                <div class="comment"><img class="commentAvatar" src="http://placehold.it/20x20"><p><a href="">Samir Nasri</a> preums</p></div>
                <div class="comment"><img class="commentAvatar" src="http://placehold.it/20x20"><p><a href="">Tartempion</a> Yeahhhhhhhhhh blabblalalalalalallalalala alzlazla</p></div>
                <div class="comment see-more-comments"><a href="">Voir tous les commentaires...</a></div>
              </div>
            </div>

            <div class="box">
              <header>
                <h3>On veut faire 10000 vus sur notre site de bg</h3>
              </header>
              <div class="img-bloc">
                <div class="help-wish"><i class="icon-thumbs-up"></i> J'aide</div>
                <div class="like-wish"><i class="icon-heart"></i> Je soutiens</div>
                <div class="comment-wish"><i class="icon-comment"></i> Je commente</div>
                <img src="img/wish-picture/img-6.png">
              </div>
              <div class="popularity">
               <span>100000 <i class="icon-eye-open"></i></span>
               <span>10 <i class="icon-heart"></i></span>
               <span>100 <i class=" icon-comment"></i></span>
              </div>
              <div class="comments">
               <div class="comment"><img class="commentAvatar" src="http://placehold.it/20x20"><p>Par <a href="">Thomas Bertin</a></p></div>
                <div class="comment"><img class="commentAvatar" src="http://placehold.it/20x20"><p><a href="">Matieu Raverdy</a> Trop stylé ton souhait, je kiffe</p></div>
                <div class="comment"><img class="commentAvatar" src="http://placehold.it/20x20"><p><a href="">Samir Nasri</a> preums</p></div>
                <div class="comment"><img class="commentAvatar" src="http://placehold.it/20x20"><p><a href="">Tartempion</a> Yeahhhhhhhhhh blabblalalalalalallalalala alzlazla</p></div>
                <div class="comment see-more-comments"><a href="">Voir tous les commentaires...</a></div>
              </div>
            </div>

            <div class="box">
              <header>
                <h3>Je souhaite visiter le sud de la France</h3>
              </header>
              <div class="img-bloc">
                <div class="help-wish"><i class="icon-thumbs-up"></i> J'aide</div>
                <div class="like-wish"><i class="icon-heart"></i> Je soutiens</div>
                <div class="comment-wish"><i class="icon-comment"></i> Je commente</div>
                <img src="img/wish-picture/img-7.png">
              </div>
              <div class="popularity">
               <span>100000 <i class="icon-eye-open"></i></span>
               <span>10 <i class="icon-heart"></i></span>
               <span>100 <i class=" icon-comment"></i></span>
              </div>
              <div class="comments">
               <div class="comment"><img class="commentAvatar" src="http://placehold.it/20x20"><p>Par <a href="">Thomas Bertin</a></p></div>
                <div class="comment"><img class="commentAvatar" src="http://placehold.it/20x20"><p><a href="">Matieu Raverdy</a> Trop stylé ton souhait, je kiffe</p></div>
                <div class="comment"><img class="commentAvatar" src="http://placehold.it/20x20"><p><a href="">Samir Nasri</a> preums</p></div>
                <div class="comment"><img class="commentAvatar" src="http://placehold.it/20x20"><p><a href="">Tartempion</a> Yeahhhhhhhhhh blabblalalalalalallalalala alzlazla</p></div>
                <div class="comment see-more-comments"><a href="">Voir tous les commentaires...</a></div>
              </div>
            </div>

            <div class="box">
              <header>
                <h3>Je souhaite aller en Hollande en vélo</h3>
              </header>
              <div class="img-bloc">
                <div class="help-wish"><i class="icon-thumbs-up"></i> J'aide</div>
                <div class="like-wish"><i class="icon-heart"></i> Je soutiens</div>
                <div class="comment-wish"><i class="icon-comment"></i> Je commente</div>
                <img src="img/wish-picture/img-8.png">
              </div>
              <div class="popularity">
               <span>100000 <i class="icon-eye-open"></i></span>
               <span>10 <i class="icon-heart"></i></span>
               <span>100 <i class=" icon-comment"></i></span>
              </div>
              <div class="comments">
               <div class="comment"><img class="commentAvatar" src="http://placehold.it/20x20"><p>Par <a href="">Thomas Bertin</a></p></div>
                <div class="comment"><img class="commentAvatar" src="http://placehold.it/20x20"><p><a href="">Matieu Raverdy</a> Trop stylé ton souhait, je kiffe</p></div>
                <div class="comment"><img class="commentAvatar" src="http://placehold.it/20x20"><p><a href="">Samir Nasri</a> preums</p></div>
                <div class="comment"><img class="commentAvatar" src="http://placehold.it/20x20"><p><a href="">Tartempion</a> Yeahhhhhhhhhh blabblalalalalalallalalala alzlazla</p></div>
                <div class="comment see-more-comments"><a href="">Voir tous les commentaires...</a></div>
              </div>
            </div>
      </div>
    </div><!--/span-->
  </div><!--/row-->
  <p id="back-top">
    <a href="#top"><span></span></a>
  </p>
</div><!--/.fluid-container-->
<footer>
  <div class="container-fluid">
    <p>&copy; Djinn mothafuka 2012</p>
  </div>
</footer>
<script type="text/javascript" src="http://code.jquery.com/jquery-1.7.2.min.js"></script>
<script src="js/bootstrap-dropdown.js"></script>
<script src="js/bootstrap-collapse.js"></script>
<script src="js/masonry.js"></script>
<script src="js/main.js"></script>
<!-- Google + button -->
<script type="text/javascript">
  window.___gcfg = {lang: 'fr'};
  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/plusone.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
</script>
<!--Facebook Like button-->
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/fr_FR/all.js#xfbml=1&appId=402347346466537";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
</body>
</html>
